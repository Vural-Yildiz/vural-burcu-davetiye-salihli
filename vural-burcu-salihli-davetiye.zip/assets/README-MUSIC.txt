Müzik dosyası henüz verilmediği için bu klasöre telifli veya varsayımsal bir parça eklenmemiştir.

Dosya geldiğinde örneğin:
assets/music.mp3

olarak koyun ve app.js içindeki CONFIG.musicSrc değerini:
'assets/music.mp3'

olarak değiştirin.
